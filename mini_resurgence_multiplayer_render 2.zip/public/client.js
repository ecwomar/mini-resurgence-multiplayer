const socket = io();
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let players = {};
let bullets = [];

const myPlayer = {
  x: 400, y: 300, id: null, color: getRandomColor()
};

function getRandomColor() {
  return '#' + Math.floor(Math.random()*16777215).toString(16);
}

function drawPlayer(player) {
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, 20, 20);
}

function drawBullet(b) {
  ctx.fillStyle = 'yellow';
  ctx.beginPath();
  ctx.arc(b.x, b.y, 5, 0, Math.PI * 2);
  ctx.fill();
}

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let id in players) drawPlayer(players[id]);
  bullets.forEach(drawBullet);
  requestAnimationFrame(gameLoop);
}

document.addEventListener('keydown', (e) => {
  socket.emit('move', e.key);
});

canvas.addEventListener('click', (e) => {
  const rect = canvas.getBoundingClientRect();
  const dx = e.clientX - rect.left - myPlayer.x;
  const dy = e.clientY - rect.top - myPlayer.y;
  socket.emit('shoot', { dx, dy });
});

socket.on('init', (data) => {
  myPlayer.id = data.id;
  players = data.players;
});

socket.on('state', (data) => {
  players = data.players;
  bullets = data.bullets;
});

gameLoop();
