const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('client'));

let players = {};
let bullets = [];

function updateBullets() {
  bullets.forEach((b, i) => {
    b.x += b.dx;
    b.y += b.dy;
    if (b.x < 0 || b.x > 800 || b.y < 0 || b.y > 600) bullets.splice(i, 1);
  });
}

io.on('connection', (socket) => {
  console.log('Player connected:', socket.id);
  players[socket.id] = { x: 400, y: 300, color: '#' + Math.floor(Math.random()*16777215).toString(16) };

  socket.emit('init', { id: socket.id, players });

  socket.on('move', (key) => {
    const p = players[socket.id];
    if (!p) return;
    if (key === 'ArrowUp') p.y -= 5;
    if (key === 'ArrowDown') p.y += 5;
    if (key === 'ArrowLeft') p.x -= 5;
    if (key === 'ArrowRight') p.x += 5;
  });

  socket.on('shoot', (data) => {
    const p = players[socket.id];
    if (!p) return;
    const mag = Math.sqrt(data.dx * data.dx + data.dy * data.dy);
    bullets.push({
      x: p.x + 10,
      y: p.y + 10,
      dx: (data.dx / mag) * 5,
      dy: (data.dy / mag) * 5
    });
  });

  socket.on('disconnect', () => {
    console.log('Player disconnected:', socket.id);
    delete players[socket.id];
  });
});

setInterval(() => {
  updateBullets();
  io.emit('state', { players, bullets });
}, 1000 / 30);

http.listen(process.env.PORT || 3000, () => {
  console.log('Server started');
});
